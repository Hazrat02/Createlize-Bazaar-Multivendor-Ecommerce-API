<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
  <title inertia><?php echo e(config('app.name', 'Createlize Bazaar')); ?></title>
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/lineicons.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/materialdesignicons.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/fullcalendar.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/main.css')); ?>" />
  <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
  <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
</head>
<body>
  <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
</body>
</html>
<?php /**PATH C:\Users\Hazrat ali\Desktop\MY work\createlize-bazaar\resources\views/app.blade.php ENDPATH**/ ?>