<template>
  <div>
    <!-- ======== sidebar-nav start =========== -->
    <aside class="sidebar-nav-wrapper" :class="{ active: sidebarOpen }">
      <div class="navbar-logo">
        <a href="/admin/dashboard">
          <img src="@/../admin/assets/images/logo/logo.svg" alt="logo" />
        </a>
      </div>

      <nav class="sidebar-nav">
        <ul>
          <li class="nav-item nav-item-has-children">
            <a href="#" @click.prevent="toggleMenu('dashboard')" :aria-expanded="menuOpen.dashboard ? 'true' : 'false'">
              <span class="icon">
                <i class="lni lni-dashboard"></i>
              </span>
              <span class="text">Dashboard</span>
            </a>
            <ul class="collapse dropdown-nav" :class="{ show: menuOpen.dashboard }">
              <li><a :class="{ active: isActive('/admin/dashboard') }" href="/admin/dashboard">Overview</a></li>
            </ul>
          </li>

          <li class="nav-item">
            <a href="/admin/categories" :class="{ active: isActive('/admin/categories') }">
              <span class="icon"><i class="lni lni-list"></i></span>
              <span class="text">Categories</span>
            </a>
          </li>

          <li class="nav-item">
            <a href="/admin/subcategories" :class="{ active: isActive('/admin/subcategories') }">
              <span class="icon"><i class="lni lni-layers"></i></span>
              <span class="text">Subcategories</span>
            </a>
          </li>

          <li class="nav-item">
            <a href="/admin/deliveries" :class="{ active: isActive('/admin/deliveries') }">
              <span class="icon"><i class="lni lni-delivery"></i></span>
              <span class="text">Delivery Types & Fields</span>
            </a>
          </li>

          <li class="nav-item">
            <a href="/admin/vendors" :class="{ active: isActive('/admin/vendors') }">
              <span class="icon"><i class="lni lni-user"></i></span>
              <span class="text">Vendor Manage</span>
            </a>
          </li>

          <li class="nav-item">
            <a href="/admin/products" :class="{ active: isActive('/admin/products') }">
              <span class="icon"><i class="lni lni-package"></i></span>
              <span class="text">Products</span>
            </a>
          </li>

          <li class="nav-item">
            <a href="/admin/users" :class="{ active: isActive('/admin/users') }">
              <span class="icon"><i class="lni lni-users"></i></span>
              <span class="text">Users</span>
            </a>
          </li>

          <li class="nav-item">
            <a href="/admin/orders" :class="{ active: isActive('/admin/orders') }">
              <span class="icon"><i class="lni lni-cart"></i></span>
              <span class="text">Orders</span>
            </a>
          </li>

          <li class="nav-item">
            <a href="/admin/coupons" :class="{ active: isActive('/admin/coupons') }">
              <span class="icon"><i class="lni lni-offer"></i></span>
              <span class="text">Coupons</span>
            </a>
          </li>

          <li class="nav-item nav-item-has-children">
            <a href="#" @click.prevent="toggleMenu('content')" :aria-expanded="menuOpen.content ? 'true' : 'false'">
              <span class="icon"><i class="lni lni-write"></i></span>
              <span class="text">Content Manage</span>
            </a>
            <ul class="collapse dropdown-nav" :class="{ show: menuOpen.content }">
              <li><a href="/admin/content" :class="{ active: isActive('/admin/content') }">Pages & FAQs</a></li>
            </ul>
          </li>

          <li class="nav-item nav-item-has-children">
            <a href="#" @click.prevent="toggleMenu('payment')" :aria-expanded="menuOpen.payment ? 'true' : 'false'">
              <span class="icon"><i class="lni lni-credit-cards"></i></span>
              <span class="text">Payment Manage</span>
            </a>
            <ul class="collapse dropdown-nav" :class="{ show: menuOpen.payment }">
              <li><a href="/admin/payments/uddoktapay" :class="{ active: isActive('/admin/payments/uddoktapay') }">UddoktaPay</a></li>
            </ul>
          </li>

          <li class="nav-item">
            <a href="/admin/smtp" :class="{ active: isActive('/admin/smtp') }">
              <span class="icon"><i class="lni lni-envelope"></i></span>
              <span class="text">SMTP Manage</span>
            </a>
          </li>

          <li class="nav-item">
            <a href="/admin/invoice-template" :class="{ active: isActive('/admin/invoice-template') }">
              <span class="icon"><i class="lni lni-printer"></i></span>
              <span class="text">Invoice Template</span>
            </a>
          </li>

          <li class="nav-item">
            <a href="/admin/seo" :class="{ active: isActive('/admin/seo') }">
              <span class="icon"><i class="lni lni-search"></i></span>
              <span class="text">SEO Manage</span>
            </a>
          </li>

          <li class="nav-item">
            <a href="/admin/settings" :class="{ active: isActive('/admin/settings') }">
              <span class="icon"><i class="lni lni-cog"></i></span>
              <span class="text">Settings</span>
            </a>
          </li>

          <li class="nav-item">
            <a href="/admin/api-docs" :class="{ active: isActive('/admin/api-docs') }">
              <span class="icon"><i class="lni lni-code"></i></span>
              <span class="text">API Docs</span>
            </a>
          </li>
        </ul>
      </nav>
    </aside>
    <div class="overlay" :class="{ active: sidebarOpen }" @click="sidebarOpen = false"></div>
    <!-- ======== sidebar-nav end =========== -->

    <!-- ======== main-wrapper start =========== -->
    <main class="main-wrapper">
      <!-- ========== header start ========== -->
      <header class="header">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-5 col-md-5 col-6">
              <div class="header-left d-flex align-items-center">
                <div class="menu-toggle-btn mr-15">
                  <button type="button" class="main-btn primary-btn-outline btn-hover" @click="sidebarOpen = !sidebarOpen">
                    <i class="lni lni-menu"></i>
                  </button>
                </div>
                <div class="header-search d-none d-md-flex">
                  <input type="text" class="form-control" placeholder="Search..." v-model="search" @keydown.enter="onSearch" />
                </div>
              </div>
            </div>
            <div class="col-lg-7 col-md-7 col-6">
              <div class="header-right">
                <div class="profile-box ml-15">
                  <button class="dropdown-toggle bg-transparent border-0" type="button" @click="profileOpen = !profileOpen">
                    <div class="profile-info">
                      <div class="info">
                        <h6 class="mb-0">{{ user?.name || 'Admin' }}</h6>
                        <div class="image">
                          <img src="@/../admin/assets/images/profile/profile-image.png" alt="" />
                        </div>
                      </div>
                    </div>
                  </button>
                  <ul class="dropdown-menu dropdown-menu-end" :class="{ show: profileOpen }">
                    <li><a class="dropdown-item" href="/admin/settings">Settings</a></li>
                    <li>
                      <form method="POST" action="/admin/logout">
                        <input type="hidden" name="_token" :value="csrf" />
                        <button type="submit" class="dropdown-item">Logout</button>
                      </form>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
      <!-- ========== header end ========== -->

      <section class="section">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <slot />
            </div>
          </div>
        </div>
      </section>

      <footer class="footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-6 order-last order-md-first">
              <div class="copyright">
                <p class="text-sm">© {{ new Date().getFullYear() }} Createlize Bazaar</p>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </main>
    <!-- ======== main-wrapper end =========== -->
  </div>
</template>

<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { usePage } from '@inertiajs/vue3'

const page = usePage()
const user = computed(() => page.props.auth?.user)
const csrf = computed(() => page.props.csrf_token || document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '')

const sidebarOpen = ref(false)
const profileOpen = ref(false)
const search = ref('')

const menuOpen = reactive({
  dashboard: true,
  content: false,
  payment: false,
})

function toggleMenu(key) {
  menuOpen[key] = !menuOpen[key]
}

function isActive(prefix) {
  return (page.url || window.location.pathname).startsWith(prefix)
}

function onSearch() {
  // optional: implement client-side search for lists in pages
}

watch(
  () => page.url,
  () => {
    profileOpen.value = false
    sidebarOpen.value = false
  }
)
</script>

<style scoped>
/* Make dropdown work without bootstrap JS */
.dropdown-menu {
  display: none;
}
.dropdown-menu.show {
  display: block;
}
</style>
