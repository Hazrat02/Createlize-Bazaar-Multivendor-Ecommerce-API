<div style="font-family: Arial, sans-serif; color: #111827;">
  <div style="display: flex; justify-content: space-between; align-items: flex-start;">
    <div style="max-width: 360px;">
      <h2 style="margin: 0 0 6px;"><?php echo e($template['company_name'] ?? 'Company'); ?></h2>
      <div style="color: #6b7280; font-size: 12px;"><?php echo e($template['company_address'] ?? ''); ?></div>
    </div>
    <div>
      <div><strong>Invoice</strong></div>
      <div style="color: #6b7280; font-size: 12px;">Order #<?php echo e($order->order_number ?? $order->id); ?></div>
      <div style="color: #6b7280; font-size: 12px;">Date: <?php echo e($order->created_at?->format('Y-m-d')); ?></div>
    </div>
  </div>

  <div style="margin-top: 16px;">
    <strong>Bill To</strong>
    <div style="color: #6b7280; font-size: 12px;"><?php echo e($order->customer?->name ?? '-'); ?></div>
    <div style="color: #6b7280; font-size: 12px;"><?php echo e($order->customer?->email ?? ''); ?></div>
  </div>

  <table style="width: 100%; border-collapse: collapse; margin-top: 16px;">
    <thead>
      <tr>
        <th style="text-align: left; border-bottom: 1px solid #e5e7eb; padding: 8px 6px; font-size: 14px; background: #f9fafb;">
          Item
        </th>
        <th style="text-align: left; border-bottom: 1px solid #e5e7eb; padding: 8px 6px; font-size: 14px; background: #f9fafb;">
          Qty
        </th>
        <th style="text-align: left; border-bottom: 1px solid #e5e7eb; padding: 8px 6px; font-size: 14px; background: #f9fafb;">
          Price
        </th>
        <th style="text-align: left; border-bottom: 1px solid #e5e7eb; padding: 8px 6px; font-size: 14px; background: #f9fafb;">
          Total
        </th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td style="text-align: left; border-bottom: 1px solid #e5e7eb; padding: 8px 6px; font-size: 14px;">
            <?php echo e($item->product_name ?? $item->product?->name ?? 'Item'); ?>

          </td>
          <td style="text-align: left; border-bottom: 1px solid #e5e7eb; padding: 8px 6px; font-size: 14px;">
            <?php echo e($item->qty ?? 1); ?>

          </td>
          <td style="text-align: left; border-bottom: 1px solid #e5e7eb; padding: 8px 6px; font-size: 14px;">
            <?php echo e(number_format((float) ($item->unit_price ?? 0), 2)); ?>

          </td>
          <td style="text-align: left; border-bottom: 1px solid #e5e7eb; padding: 8px 6px; font-size: 14px;">
            <?php echo e(number_format((float) ($item->line_total ?? 0), 2)); ?>

          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <table style="width: 100%; border-collapse: collapse; margin-top: 16px;">
    <tbody>
      <tr>
        <td style="text-align: right; font-weight: 700; padding: 6px;">Subtotal</td>
        <td style="text-align: right; font-weight: 700; padding: 6px;">
          <?php echo e(number_format((float) ($order->subtotal ?? 0), 2)); ?>

        </td>
      </tr>
      <tr>
        <td style="text-align: right; font-weight: 700; padding: 6px;">Discount</td>
        <td style="text-align: right; font-weight: 700; padding: 6px;">
          -<?php echo e(number_format((float) ($order->discount_total ?? 0), 2)); ?>

        </td>
      </tr>
      <tr>
        <td style="text-align: right; font-weight: 700; padding: 6px;">Total</td>
        <td style="text-align: right; font-weight: 700; padding: 6px;">
          <?php echo e(number_format((float) ($order->total ?? 0), 2)); ?>

        </td>
      </tr>
    </tbody>
  </table>

  <div style="margin-top: 24px; font-size: 12px; color: #6b7280;">
    <?php echo e($template['footer_note'] ?? ''); ?>

  </div>
</div>
<?php /**PATH C:\Users\Hazrat ali\Desktop\MY work\createlize-bazaar\resources\views/emails/invoice-fragment.blade.php ENDPATH**/ ?>